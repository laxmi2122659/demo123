from flask import Flask,render_template,request
import csv

app = Flask(__name__)

patient_data = []
with open('patient_data.csv') as csvfile:
    csvreader = csv.reader(csvfile)
    for row in csvreader:
        patient_data.append(row)
 
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/patient-login')
def patient():
    return render_template('patient-login.html')

@app.route('/doctor-login')
def doctor():
    return render_template('doctor-login.html')

@app.route('/select-hospital', methods=['GET','POST'])
def hosp_sel():
    if request.method == 'POST':
        doctor_name = request.form['doctor_name']
        password = request.form['password']
        hospitals = []
        for x in patient_data:
            if x[13] == doctor_name and x[15] == password:
                hospitals.append(x[16])
        
        
        return render_template('doct-hos.html',hospitals = hospitals) 
    else:
        return render_template('doctor-login.html')
    
@app.route('/select-hospital/<hospital>', methods=['GET','POST'])
def show_patient_data(hospital):
    print('u')
    patients = []
    for x in patient_data:
        if x[13] == doctor_name and x[16] == hospital:
            patients.append(x)
    return render_template('doctor-db.html', patients=patients)

@app.route('/validate', methods=['GET','POST'])
def validate():
    if request.method == 'POST':
        first_name = request.form['first-name']
        last_name = request.form['last-name']
        password = request.form['password']
        password = password[5:7] + "/" + password[8:] + "/" + password[:4]
                
    
        for row in patient_data:
            if row[1] == first_name and row[2] == last_name and row[3] == password:
                bp = row[12]
                heart_rate = row[11]
                return render_template('patient-db.html',first_name = first_name, last_name = last_name, bp=bp, heart_rate=heart_rate)
        
        error = "Invalid patient name or date of birth. Please try again."
        return render_template('patient-login.html',error=error)

                        

if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port = 8080)
