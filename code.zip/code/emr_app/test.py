
import os

from google.cloud.sql.connector import Connector, IPTypes
import pymysql

import sqlalchemy


def connect_with_connector() -> sqlalchemy.engine.base.Engine:
    """
    Initializes a connection pool for a Cloud SQL instance of MySQL.
    Uses the Cloud SQL Python Connector package.
    """
    # Note: Saving credentials in environment variables is convenient, but not
    # secure - consider a more secure solution such as
    # Cloud Secret Manager (https://cloud.google.com/secret-manager) to help
    # keep secrets safe.

    instance_connection_name = "k8s-sql-384108:us-central1:instance"  # e.g. 'project:region:instance'
    db_user = "user" # e.g. 'my-db-user'
    db_pass = "123"  # e.g. 'my-db-password'
    db_name = "db" # e.g. 'my-database'

    ip_type = IPTypes.PRIVATE if os.environ.get("PRIVATE_IP") else IPTypes.PUBLIC

    connector = Connector(ip_type)

    def getconn() -> pymysql.connections.Connection:
        conn: pymysql.connections.Connection = connector.connect(
            instance_connection_name,
            "pymysql",
            user=db_user,
            password=db_pass,
            db=db_name,
        )
        return conn

    pool = sqlalchemy.create_engine(
        "mysql+pymysql://",
        creator=getconn,
        # [START_EXCLUDE]
        # Pool size is the maximum number of permanent connections to keep.
        pool_size=5,

        # Temporarily exceeds the set pool_size if no connections are available.
        max_overflow=2,

        # The total number of concurrent connections for your application will be
        # a total of pool_size and max_overflow.

        # 'pool_timeout' is the maximum number of seconds to wait when retrieving a
        # new connection from the pool. After the specified amount of time, an
        # exception will be thrown.
        pool_timeout=30,  # 30 seconds

        # 'pool_recycle' is the maximum number of seconds a connection can persist.
        # Connections that live longer than the specified amount of time will be
        # re-established
        pool_recycle=1800,  # 30 minutes
        # [END_EXCLUDE]
    )
    return pool

# [END cloud_sql_mysql_sqlalchemy_connect_connector]

from flask import Flask,render_template,request

app = Flask(__name__)
engine = connect_with_connector()
query = 'SELECT * FROM patient_data'
with engine.connect() as connection:
    result = connection.execute(query)
    patient_data = [list(row) for row in result]
    
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/patient-login')
def patient():
    return render_template('patient-login.html')

@app.route('/doctor-login')
def doctor():
    return render_template('doctor-login.html')

@app.route('/select-hospital', methods=['GET','POST'])
def hosp_sel():
    if request.method == 'POST':
        doctor_name = request.form['doctor_name']
        password = request.form['password']
        hospitals = []
        for x in patient_data:
            if x[13] == doctor_name and x[15] == password:
                hospitals.append(x[16])
        
        
        return render_template('doct-hos.html',hospitals = hospitals) 
    else:
        return render_template('doctor-login.html')
    
@app.route('/select-hospital/<hospital>', methods=['GET','POST'])
def show_patient_data(hospital):
    print('u')
    patients = []
    for x in patient_data:
        if x[13] == doctor_name and x[16] == hospital:
            patients.append(x)
    return render_template('doctor-db.html', patients=patients)

@app.route('/validate', methods=['GET','POST'])
def validate():
    if request.method == 'POST':
        first_name = request.form['first-name']
        last_name = request.form['last-name']
        password = request.form['password']
        password = password[5:7] + "/" + password[8:] + "/" + password[:4]
                
    
        for row in patient_data:
            if row[1] == first_name and row[2] == last_name and row[3] == password:
                bp = row[12]
                heart_rate = row[11]
                return render_template('patient-db.html',first_name = first_name, last_name = last_name, bp=bp, heart_rate=heart_rate)
        
        error = "Invalid patient name or date of birth. Please try again."
        return render_template('patient-login.html',error=error)

                        

if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port = 8080)